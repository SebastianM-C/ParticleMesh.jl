#!/usr/bin/env bash
O=~/pm-gridppc/out2
until grep -q "^# all finished" $O/status.txt 2>/dev/null; do
  { nvidia-smi --query-gpu=timestamp,utilization.gpu,memory.used --format=csv,noheader; nvidia-smi --query-compute-apps=pid,used_memory --format=csv,noheader; } >> $O/gpu-samples.csv
  sleep 5
done
