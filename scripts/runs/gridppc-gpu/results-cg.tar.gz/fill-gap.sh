#!/usr/bin/env bash
# Waits (at most 12 h) until the card has >= 20 GiB free and no compute process but the compositor,
# then reruns the cg campaign once (only jobs without a .json run) with a 5 s GPU sampler, and exits.
O=~/pm-gridppc/out3
deadline=$(( $(date +%s) + 12*3600 ))
echo "armed $(date -u +%FT%TZ), pid $$"
while :; do
  free=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -n1)
  others=$(nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader | grep -v kwin_wayland | grep -c .)
  [ "${free:-0}" -ge 20480 ] && [ "$others" -eq 0 ] && break
  [ $(date +%s) -ge $deadline ] && { echo "gave up $(date -u +%FT%TZ): free=$free MiB, other compute processes=$others"; exit 1; }
  sleep 60
done
echo "card free $(date -u +%FT%TZ): $free MiB free"
[ -e $O/cg/cg-grid-r96x6-grad.err ] && mv $O/cg/cg-grid-r96x6-grad.err $O/cg-grid-r96x6-grad.err.first-attempt
( while :; do { nvidia-smi --query-gpu=timestamp,utilization.gpu,memory.used --format=csv,noheader; nvidia-smi --query-compute-apps=pid,used_memory --format=csv,noheader; } >> $O/gpu-samples.csv; sleep 5; done ) &
spid=$!
cd ~/pm-gridppc/src && scripts/resolution/run_gpu.sh $O cg > ~/pm-gridppc/runner3b.log 2>&1 < /dev/null
rc=$?
kill $spid
echo "runner exited $rc $(date -u +%FT%TZ)"
